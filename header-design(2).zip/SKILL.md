# Skill: edit or create rens-place header art

You are editing the pixel-art header of a personal website. The scene is a sunset over a beach seen from a walnut deck on the left, with Aspen the shark sitting at the end of the deck, a palm tree, gulls, clouds and dune grass. It is tiny pixel art scaled up with crisp pixels, so think in single pixels.

## Files in this zip
- design.json: the current design (the source of truth)
- preview.png: frame 1 of the design, scaled up so you can look at it
- SKILL.md: this file

## design.json format ("rens-header/3")
- w, h: canvas size in pixels (this design: 560 x 192). Keep them unless asked to change them.
- fps, frames: animation speed and frame count (1 means a still image).
- palette: a list of "#rrggbb" colours with no size limit. Pixels refer to a colour by its number: 1 is the first colour in the list, 2 the second, and so on. 0 means transparent. (Older designs used {"a":"#rrggbb", ...} with one-character keys and string rows; both are still read, but write the numbered form.)
- layers: listed BOTTOM to TOP. Each has name, visible, opacity (0 to 1), animated (true or false), bind (a joint name or null) and frames.
- frames: a list of frames. Each frame is a list of exactly h rows, and each row is a list of exactly w whole numbers (0 for transparent, otherwise a palette number from 1 up to the length of the palette).
- A layer with animated false has exactly one frame, shown on every animation frame. A layer with animated true has exactly "frames" frames.
- Layer "type" is "pixels" (the default, with frames) or "code" (see below). Any layer may have "mask":"other layer name": it is then drawn only where that layer has pixels (a pixel layer: any non-"." pixel; a code layer: wherever it draws). "maskInvert":true flips this. Mask layers are normally "visible":false.
- A code layer has "code": the BODY of a JavaScript function(ctx, t, api) that runs about 12 times per second. ctx is a 2D canvas context api.w x api.h pixels (api.w can be wider than the design w on wide screens, so place things relative to api.w and reuse api.h). t is time in seconds. Draw whole-pixel solid colours only. Helpers: api.hash(a,b,c) gives repeatable noise 0..1; api.px(ctx,x,y,colour); api.rect(ctx,x,y,w,h,colour); api.disc(ctx,cx,cy,r,colour,clipY); api.halo(ctx,cx,cy,r,colour,parity,clipY) is a dithered disc; api.mk(w,h) makes a canvas; api.S is an object that survives between frames, so cache expensive work there (build a canvas once, then ctx.drawImage it); api.Sprite builds Aspen. Code runs unsandboxed in the page: only draw, never touch the network, storage or the DOM.
- skeleton (optional): joints [{name,x,y,parent}] in canvas pixels at rest (parent is null for the root). poses is a list with one object per animation frame, mapping joint name to a rotation in degrees (clockwise, about that joint, children follow). A layer with "bind":"jointname" moves rigidly with that joint.

## How to work
0. Existing code layers are working examples of the style: read them before writing new ones.
1. Read design.json and look at preview.png.
2. Prefer a small script (Python is good) that loads design.json, changes it and writes the full file back. Typing thousands of characters by hand causes off-by-one row errors.
3. Before replying, check: every row has length w, every frame has h rows, every number is 0 or a valid palette number, layer frame counts follow the rules above, and every code layer is valid JavaScript.
4. Leave layers you were not asked to touch exactly as they are. Add new things as new, clearly named layers.
5. Style: a limited palette, checker dithering where colour bands meet, no anti-aliasing, outlines slightly darker than their fill. Reuse existing palette numbers where you can; you may add as many new colours to the end of the palette as you need.

## Reply format
Reply with the COMPLETE updated design.json (not a diff), either as one ```json code block or as a zip containing design.json. Add one line saying what you changed, outside the JSON.
To create a new design from scratch, use the same format: choose w and h (default 320 x 150), build the layers and reply the same way.
